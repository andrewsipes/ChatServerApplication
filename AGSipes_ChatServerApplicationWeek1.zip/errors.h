#pragma once

#define MAX_CHAR_LENGTH 255
#define MAX_UNPW_CHAR_LENGTH 20

#define SUCCESS 0
#define SHUTDOWN 1
#define DISCONNECT 2
#define BIND_ERROR 3
#define CONNECT_ERROR 4
#define STARTUP_ERROR 6
#define ADDRESS_ERROR 7
#define PARAMETER_ERROR 8
#define MESSAGE_ERROR 9
#define CLIENT_DISCONNCTED 10
#define INCORRECT_UN_OR_PW 11
#define ALREADY_REGISTERED 12
#define REGISTRATION_FAILED 13
#define FAILED_TO_SEND 14
#define CHAR_LIMIT_REACHED 15
#define LOG_RETRIEVAL_FAILED 16
#define INCORRECT_COMMAND 17
#define INCORRECT_PORT 18
#define CAPACITY_REACHED 19
#define INCORRECT_IP 20
#define NOT_LOGGED_IN 21
#define INTERNAL_ERROR 22
#define SETUP_ERROR -1

//These are just used for returns for determining which command was sent
#define HELP_SCREEN 100
#define REGISTER 101

