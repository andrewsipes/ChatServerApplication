#include "user.h"

user::user(std::string _username, std::string _password) {
	username = _username;
	password = _password;
}

user::~user() {

}